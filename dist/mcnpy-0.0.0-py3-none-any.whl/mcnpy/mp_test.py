from multiprocessing import Process, Value, Array, Queue, Pipe

def f(n, a, q):
    n.value = 3.1415927
    for i in range(len(a)):
        a[i] = -a[i]
        q.put(a[i])

if __name__ == '__main__':
    num = Value('d', 0.0)
    arr = Array('i', range(10))
    conn1, conn2 = Pipe(duplex=True)

    q = Queue()
    p = Process(target=f, args=(num, arr, q))
    p.start()
    p.join()

    print(num.value)
    print(arr[:])
    print(q.get())
    print(q.qsize())
    print(q.get())