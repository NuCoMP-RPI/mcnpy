import math
import re
import numpy as np

import openmc
from openmc.model.surface_composite import XConeOneSided, YConeOneSided, ZConeOneSided
import mcnpy as mp

from mcnpy.surfaces import Sphere
from mcnpy.surfaces import Plane, XPlane, YPlane, ZPlane
from mcnpy.surfaces import XCylinder, YCylinder, ZCylinder 
from mcnpy.surfaces import XCone, YCone, ZCone
from mcnpy.surfaces import Quadric, XYZQuadric 
from mcnpy.surfaces import PPoints, Sphere , XTorus, YTorus, ZTorus
from mcnpy.surfaces import PPoints, XPoints, YPoints, ZPoints
from mcnpy.surfaces import XTorus, YTorus, ZTorus

DEG_RAD = 180. / math.pi
RAD_DEG = 1 / DEG_RAD

"""Translate MCNP to OpenMC.
"""
def decompose_transformation(transform, angle='COSINES'):
    """
    """
    #TODO: Consider angle units and other options.
    #TODO: decomposed transformations should be stored for reuse.
    vector = [transform.disp1, transform.disp2, transform.disp3]
    rot = transform.rotation
    if rot is not None:
        rotX = np.array([rot.xx, rot.yx, rot.zx])
        rotY = np.array([rot.xy, rot.yy, rot.zy])
        rotZ = np.array([rot.xz, rot.yz, rot.zz])

        if str(angle) == 'DEGREES' or str(angle) == '*':
            rotX = np.cos(rotX * RAD_DEG)
            rotY = np.cos(rotY * RAD_DEG)
            rotZ = np.cos(rotZ * RAD_DEG)

        # If a set is all == 0, then it was jumped.
        # Replacing with defaults.
        #TODO: Fix this assumption for defaults.
        if rotX[0] == 0 and rotX[1] == 0 and rotX[2] == 0:
            rotX = [1.0, 0.0, 0.0]
        if rotY[0] == 0 and rotY[1] == 0 and rotY[2] == 0:
            rotY = [0.0, 1.0, 0.0]
        if rotZ[0] == 0 and rotZ[1] == 0 and rotZ[2] == 0:
            rotZ = [0.0, 0.0, 1.0]

        rot_matrix = np.array([rotX, rotY, rotZ]).transpose()
    else:
        rot_matrix = None

    return (vector, rot_matrix)

def plane_distance(p1, p2):
    """Distance between parallel planes.
    """
    # get_base_coefficients makes it agnostic to
    # XPlane, YPlane, Plane, or PointsPlane
    a = p1.get_base_coefficients()
    b = p2.get_base_coefficients()
    dist = abs(a['k'] - b['k']) / (a['g']**2 + a['h']**2 + a['j']**2)**0.5

    return dist


def decompose(deck):
    """Decompose cell complements and macrobodies.
    """
    new_surfaces = {}
    mbodies = {}
    # Define simple surface cards for macrobodies.
    for k in deck.surfaces:
        new_surfaces[k] = deck.surfaces[k]
        # Provide room for decomposing.
        if isinstance(deck.surfaces[k], mp.surfaces.Macrobody):
            surfs, region_pos, region_neg = mp.mbody_decomp.decomp(deck.surfaces[k])
            for s in range(len(surfs)):
                new_surfaces[surfs[s].name] = surfs[s]
            # Store lists of the decomposed surfaces.
            mbodies[k] = (str(region_pos), (str(region_neg).replace('(', '').replace(')','')))
    deck.surfaces = new_surfaces

    for k in deck.cells:
        # Decompose cell complements.
        # Note that a surface complement must be in parentheses and will not match '~\d'.
        region_str = str(deck.cells[k].region)
        #print(region_str)
        while len(re.findall('~\d', region_str)) > 0:
            deck.cells[k].region = mp.Region.from_expression(str(deck.cells[k].region), deck.surfaces, deck.cells)
            region_str = str(deck.cells[k].region)
        # Replace macrobodies with simple surfaces.
        for j in mbodies:
            # Negative halfspaces.
            region_str = re.sub('(?<!\d)\\-'+str(j)+'(?!\d)', mbodies[j][1], region_str)
            # Positive halfspaces.
            region_str = re.sub('(?<!\d)'+str(j)+'(?!\d)', mbodies[j][0], region_str)
        #print(deck.cells[k], region_str)
        deck.cells[k].region = mp.Region.from_expression(region_str, deck.surfaces, deck.cells)

def boundary(surf):
    #TODO: Add in the other case
    bound = str(surf.boundary_type)
    if bound == '*' or bound.upper() == 'REFLECTIVE':
        return 'reflective'
    elif bound == '+' or bound.upper() == 'WHITE':
        return 'white'
    else:
        return 'vacuum'
    
def make_plane(surf:Plane):
    """
    """
    return openmc.Plane(a=surf.a, b=surf.b, c=surf.c, d=surf.d, 
                        boundary_type=boundary(surf), name=str(surf.name))

def make_xplane(surf:XPlane):
    """
    """
    return openmc.Plane(a=1, b=0, c=0, d=surf.x0, 
                        boundary_type=boundary(surf), name=str(surf.name))

def make_yplane(surf:YPlane):
    """
    """
    return openmc.Plane(a=0, b=1, c=0, d=surf.y0,
                        boundary_type=boundary(surf), name=str(surf.name))

def make_zplane(surf:ZPlane):
    """
    """
    return openmc.Plane(a=0, b=0, c=1, d=surf.z0, 
                        boundary_type=boundary(surf), name=str(surf.name))

def make_points_plane(surf:PPoints):
    """
    """
    points = surf.points
    p1 = np.array([points[0].x, points[0].y, points[0].z])
    p2 = np.array([points[1].x, points[1].y, points[1].z])
    p3 = np.array([points[2].x, points[2].y, points[2].z])
    v1 = p3 - p1
    v2 = p2 - p1
    cp = np.cross(v2, v1)
    a, b, c = cp
    d = np.dot(cp, p3)
    return openmc.Plane(a=a/d, b=b/d, c=c/d, d=d/d, 
                        boundary_type=boundary(surf), name=str(surf.name))

def make_sphere(surf:Sphere):
    """
    """
    return openmc.Sphere(x0=surf.x0, y0=surf.y0, z0=surf.z0, r=surf.r, 
                         boundary_type=boundary(surf), name=str(surf.name))

def make_xcylinder(surf:XCylinder):
    """
    """
    coef = surf.get_base_coefficients()
    return openmc.Quadric(a=coef['a'], b=coef['b'], c=coef['c'], d=coef['d'], 
                          e=coef['e'], f=coef['f'], g=coef['g'], h=coef['h'], 
                          j=coef['j'], k=coef['k'], 
                          boundary_type=boundary(surf), name=str(surf.name))

def make_ycylinder(surf:YCylinder):
    """
    """
    coef = surf.get_base_coefficients()
    return openmc.Quadric(a=coef['a'], b=coef['b'], c=coef['c'], d=coef['d'], 
                          e=coef['e'], f=coef['f'], g=coef['g'], h=coef['h'], 
                          j=coef['j'], k=coef['k'], 
                          boundary_type=boundary(surf), name=str(surf.name))

def make_zcylinder(surf:ZCylinder):
    """
    """
    coef = surf.get_base_coefficients()
    return openmc.Quadric(a=coef['a'], b=coef['b'], c=coef['c'], d=coef['d'], 
                          e=coef['e'], f=coef['f'], g=coef['g'], h=coef['h'], 
                          j=coef['j'], k=coef['k'], 
                          boundary_type=boundary(surf), name=str(surf.name))

def make_quadric(surf:Quadric):
    """
    """
    return openmc.Quadric(a=surf.a, b=surf.b, c=surf.c, d=surf.d, e=surf.e, 
                          f=surf.f, g=surf.g, h=surf.h, j=surf.j, k=surf.k, 
                          boundary_type=boundary(surf), name=str(surf.name))

def make_xyzquadric(surf:XYZQuadric):
    """
    """
    coef = surf.get_base_coefficients()
    return openmc.Quadric(a=coef['a'], b=coef['b'], c=coef['c'], d=coef['d'], 
                          e=coef['e'], f=coef['f'], g=coef['g'], h=coef['h'], 
                          j=coef['j'], k=coef['k'], 
                          boundary_type=boundary(surf), name=str(surf.name))

def make_xcone(surf:XCone):
    """
    """
    if surf.sheet is None:
        return openmc.XCone(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                            boundary_type=boundary(surf), name=str(surf.name))
    elif str(surf.sheet.side) == '+':
        return XConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=True, boundary_type=boundary(surf), 
                             name=str(surf.name))
    elif str(surf.sheet.side) == '-':
        return XConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=False, boundary_type=boundary(surf), 
                             name=str(surf.name))
    else:
        print('This XCone is up sheet creek!', str(surf.sheet.side))

def make_ycone(surf:YCone):
    """
    """
    if surf.sheet is None:
        return openmc.YCone(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                            boundary_type=boundary(surf), name=str(surf.name))
    elif str(surf.sheet.side) == '+':
        return YConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=True, boundary_type=boundary(surf), 
                             name=str(surf.name))
    elif str(surf.sheet.side) == '-':
        return YConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=False, boundary_type=boundary(surf), 
                             name=str(surf.name))
    else:
        print('This YCone is up sheet creek!', str(surf.sheet.side))

def make_zcone(surf:ZCone):
    """
    """
    if surf.sheet is None:
        return openmc.ZCone(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                            boundary_type=boundary(surf), name=str(surf.name))
    elif str(surf.sheet.side) == '+':
        return ZConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=True, boundary_type=boundary(surf), 
                             name=str(surf.name))
    elif str(surf.sheet.side) == '-':
        return ZConeOneSided(x0=surf.x0, y0=surf.y0, z0=surf.z0, r2=surf.r2, 
                             up=False, boundary_type=boundary(surf), 
                             name=str(surf.name))
    else:
        print('This ZCone is up sheet creek!', str(surf.sheet.side))

def make_xtorus(surf:XTorus):
    """
    """
    return openmc.XTorus(x0=surf.x0, y0=surf.y0, z0=surf.z0, a=surf.a, b=surf.b, 
                         c=surf.c, boundary_type=boundary(surf), name=str(surf.name))

def make_ytorus(surf:YTorus):
    """
    """
    return openmc.YTorus(x0=surf.x0, y0=surf.y0, z0=surf.z0, a=surf.a, b=surf.b, 
                         c=surf.c, boundary_type=boundary(surf), name=str(surf.name))

def make_ztorus(surf:ZTorus):
    """
    """
    return openmc.ZTorus(x0=surf.x0, y0=surf.y0, z0=surf.z0, a=surf.a, b=surf.b, 
                         c=surf.c, boundary_type=boundary(surf), name=str(surf.name))

def make_xpoints(surf:XPoints):
    """
    """
    new_surf = surf.convert()
    if isinstance(new_surf, XPlane):
        _surf = make_xplane(new_surf)
    elif isinstance(new_surf, XCone):
        _surf = make_xcone(new_surf)
    elif isinstance(new_surf, XCylinder):
        _surf = make_xcylinder(new_surf)
    elif isinstance(new_surf, XYZQuadric):
        _surf = make_xyzquadric(new_surf)

    _surf.name = surf.name
    return surf

def make_ypoints(surf:YPoints):
    """
    """
    new_surf = surf.convert()
    if isinstance(new_surf, YPlane):
        _surf = make_yplane(new_surf)
    elif isinstance(new_surf, YCone):
        _surf = make_ycone(new_surf)
    elif isinstance(new_surf, YCylinder):
        _surf = make_ycylinder(new_surf)
    elif isinstance(new_surf, XYZQuadric):
        _surf = make_xyzquadric(new_surf)

    _surf.name = surf.name
    return surf

def make_zpoints(surf:ZPoints):
    """
    """
    new_surf = surf.convert()
    if isinstance(new_surf, ZPlane):
        _surf = make_zplane(new_surf)
    elif isinstance(new_surf, ZCone):
        _surf = make_zcone(new_surf)
    elif isinstance(new_surf, ZCylinder):
        _surf = make_zcylinder(new_surf)
    elif isinstance(new_surf, XYZQuadric):
        _surf = make_xyzquadric(new_surf)

    _surf.name = surf.name
    return surf

"""def make_cell(cell, openmc_surfaces):
    openmc_cell = openmc.Cell(int(cell.name))
    openmc_cell.region = openmc.Region.from_expression(str(cell.region), openmc_surfaces)
    # Check for cell transformations.
    cell_tr = cell.transformation
    if cell_tr is None:
        transform = cell.transformation
    else:
        transform = cell_tr.transform
    # Apply transformation to openmc cell region.
    if transform is not None:
        tr = decompose_transformation(transform)
        #openmc_cell.region = openmc_cell.region.translate(tr[0])
        openmc_cell.region = openmc_cell.region.rotate(tr[1])
        openmc_cell.region = openmc_cell.region.translate(tr[0])
    
    return openmc_cell"""

def make_material(material, id:str):
    openmc_material = openmc.Material(int(id), id)
    nuclides = material.nuclides
    for i in range(len(nuclides)):
        nuclide = nuclides[i]
        fraction = nuclide.fraction
        isotope = nuclide.name#.element_name()
        unit = 'ao'
        if str(nuclide.unit) == '-':
            unit = 'wo'
        # No C13 is present in the nuclear data library I downloaded.
        # This causes an error when using natural carbon. Use C0 instead.
        if isotope == 'C0':
            openmc_material.add_nuclide(isotope, fraction, unit)
        elif isotope[-1] == '0' and isotope[-2].isdigit() is False:
            openmc_material.add_element(isotope[:-1], fraction, unit)
        else:
            openmc_material.add_nuclide(isotope, fraction, unit)
    return openmc_material

def mcnp_to_openmc(deck:mp.Deck):
    """Generate an OpenMC file from MCNP deck.
    """
    openmc_materials = {}
    openmc_surfaces = {}
    openmc_cells = {}
    openmc_universes = {}
    openmc_transformations = {}
    lat_universes = {}
    lat_dims = {}

    # Translate materials.
    openmc_materials[0] = openmc.Material(0, 'void')
    openmc_materials[0].add_nuclide('H1', 1.0)
    openmc_materials[0].set_density('g/cm3', 1e-100)
    mats = openmc.Materials([openmc_materials[0]])

    print('Translating Materials...')
    for k in deck.materials:
        openmc_materials[int(k)] = make_material(deck.materials[k], str(k))
        mats.append(openmc_materials[int(k)])

    # Store displacements and rotations from TR cards.
    # This way their matrices are only created once.
    print('Decomposing Cell Transformations...')
    for k in deck.transformations:
        tr = deck.transformations[k]
        openmc_transformations[k] = (decompose_transformation(tr.transformation, 
                                                              tr.unit))

    # Translate surfaces.
    print('Translating Surfaces...')
    for k in deck.surfaces:
        surf = deck.surfaces[k]
        if isinstance(surf, Sphere):
            openmc_surfaces[int(k)] = make_sphere(surf)
        elif isinstance(surf, Plane):
            openmc_surfaces[int(k)] = make_plane(surf)
        elif isinstance(surf, XPlane):
            openmc_surfaces[int(k)] = make_xplane(surf)
        elif isinstance(surf, YPlane):
            openmc_surfaces[int(k)] = make_yplane(surf)
        elif isinstance(surf, ZPlane):
            openmc_surfaces[int(k)] = make_zplane(surf)
        elif isinstance(surf, PPoints):
            openmc_surfaces[int(k)] = make_points_plane(surf)
        elif isinstance(surf, Quadric):
            openmc_surfaces[int(k)] = make_quadric(surf)
        elif isinstance(surf, XYZQuadric):
            openmc_surfaces[int(k)] = make_xyzquadric(surf)
        elif isinstance(surf, XCylinder):
            openmc_surfaces[int(k)] = make_xcylinder(surf)
        elif isinstance(surf, YCylinder):
            openmc_surfaces[int(k)] = make_ycylinder(surf)
        elif isinstance(surf, ZCylinder):
            openmc_surfaces[int(k)] = make_zcylinder(surf)
        elif isinstance(surf, XCone):
            openmc_surfaces[int(k)] = make_xcone(surf)
        elif isinstance(surf, YCone):
            openmc_surfaces[int(k)] = make_ycone(surf)
        elif isinstance(surf, ZCone):
            openmc_surfaces[int(k)] = make_zcone(surf)
        elif isinstance(surf, XTorus):
            openmc_surfaces[int(k)] = make_xtorus(surf)
        elif isinstance(surf, YTorus):
            openmc_surfaces[int(k)] = make_ytorus(surf)
        elif isinstance(surf, YTorus):
            openmc_surfaces[int(k)] = make_ztorus(surf)
        elif isinstance(surf, XPoints):
            openmc_surfaces[int(k)] = make_xpoints(surf)
        elif isinstance(surf, YPoints):
            openmc_surfaces[int(k)] = make_ypoints(surf)
        elif isinstance(surf, ZPoints):
            openmc_surfaces[int(k)] = make_zpoints(surf)
        #TODO: Cones might need to become quadrics for rotations.
        else:
            print('SURFACE ERROR!\n', surf)
        
        if surf.transformation is not None:
            tr = openmc_transformations[surf.transformation.name]
            if tr[1] is not None:
                openmc_surfaces[int(k)] = openmc_surfaces[int(k)].rotate(tr[1])
            openmc_surfaces[int(k)] = openmc_surfaces[int(k)].translate(tr[0])
    print('Surface Translation Complete')

    # Translate universes.
    # Note that universe 0 contains all cells without U keyword.
    print('Translating Universes and Cells...')
    lat_u = []
    lat_disp = []
    for k in deck.universes:
        # TODO: Consider the universe's sign.
        universe = deck.universes[k]
        if int(k) not in openmc_universes.keys():
            openmc_universes[int(k)] = openmc.Universe(universe_id=int(k))
        # Loop over all cells in universe.
        #print(universe.cells)
        #print('\n', deck.cells)
        for c in universe.cells:
            # Define cell.
            cell = deck.cells[c]
            #openmc_cells[int(c)] = make_cell(cell, openmc_surfaces)
            openmc_cells[int(c)] = openmc.Cell(int(c))
            #print(str(cell.region), openmc_surfaces.keys())
            openmc_cells[int(c)].region = openmc.Region.from_expression(str(cell.region), openmc_surfaces)
            # TODO: Test cell transformations containing rotations.
            # Check for cell transformations.
            cell_tr = cell.transformation
            # None means no TR card is referenced.
            if cell_tr is None:
                transform = cell.transform
                angle = cell.transform_angle_unit
            # A transformation can be specifed directly instead.
            else:
                transform = cell_tr.transformation
                angle = cell_tr.unit
            # Apply transformation to openmc cell region.
            if transform is not None:
                if cell_tr is not None:
                    tr = openmc_transformations[cell_tr.name]
                else:
                    tr = decompose_transformation(transform, angle)
                if tr[1] is not None:
                    openmc_cells[int(c)].region = openmc_cells[int(c)].region.rotate(tr[1])
                openmc_cells[int(c)].region = openmc_cells[int(c)].region.translate(tr[0])
            
            # Cell with no FILL card.
            if cell.fill is None:
                if cell.material is None:
                    fill = openmc_materials[0]
                else:
                    density = cell.density
                    # Material has not been used by a cell yet.
                    if openmc_materials[int(cell.material.name)].density is None:
                        if str(cell.density_unit) == '-':
                            openmc_materials[int(cell.material.name)].set_density('g/cm3', density)
                        else:
                            openmc_materials[int(cell.material.name)].set_density('atom/cm3', density)
                        fill = openmc_materials[int(cell.material.name)]
                    # Material has at least one density defined for it.
                    else:
                        exist = False
                        # Check if alternate denity has already been used.
                        for m in openmc_materials:
                            if openmc_materials[m].name == cell.material.name:
                                if openmc_materials[m].density == density:
                                    exist = True
                                    fill = openmc_materials[m]
                                    break
                        # Add new material with different density.
                        if exist is False:
                            m_id = str(len(openmc_materials)+1)
                            openmc_materials[m_id] = make_material(cell.material, m_id)
                            fill = openmc_materials[m_id]
                            mats.append(fill)
            # Cell with FILL card.
            elif isinstance(cell.fill, mp.Lattice) is False:
                u_id = int(cell.fill.fill.name)
                if u_id not in openmc_universes.keys():
                    openmc_universes[u_id] = openmc.Universe(universe_id=u_id)
                fill = openmc_universes[int(cell.fill.fill.name)]
            # Lattice fill.
            else:
                u_list = []
                # Get lattice array of MCNP universes.
                lattice = cell.fill
                # Dimensions in k, j, i order
                dim = lattice.dims[::-1]
                if str(lattice.type) == '1' or str(lattice.type).upper() == 'REC':
                    openmc_lattice = np.empty(dim).astype(openmc.Universe)
                    for z in range(dim[0]):
                        for y in range(dim[1]):
                            for x in range(dim[2]):
                                #print(lattice.lattice[z,y,x])
                                u_id = int(lattice.lattice[z,y,x].fill.name)
                                if u_id not in openmc_universes.keys():
                                    openmc_universes[u_id] = openmc.Universe(universe_id=u_id)
                                openmc_lattice[z,y,x] = openmc_universes[u_id]
                                #print('\n', openmc_lattice[z,y,x], '\n')
                                if openmc_lattice[z,y,x] not in u_list:
                                    u_list.append(openmc_lattice[z,y,x])
                    lat_u.append(u_list)
                    fill = openmc.RectLattice()
                    fill.universes = openmc_lattice
                #TODO: Work on HEX lattices
                #TODO: Find out if OpenMC supports partial rings
                else:
                    # List of rings of the lattice
                    rings = lattice.rings()
                    openmc_rings = []
                    for layer in rings[0]:
                        openmc_rings.append([])
                        for ring in layer:
                            openmc_ring = []
                            for r in ring:
                                u_id = int(r.name)
                                if u_id not in openmc_universes.keys():
                                    openmc_universes[u_id] = openmc.Universe(universe_id=u_id)
                                openmc_ring.append(openmc_universes[u_id])
                                if openmc_ring[-1] not in u_list:
                                    u_list.append(openmc_ring[-1])
                            openmc_rings[-1].append(openmc_ring)
                    #TODO: get the background fill
                    # Might be redundant since we need a fully specified MCNP 
                    # lattice which means including elements outside the rings 
                    # already.
                    lat_u.append(u_list)
                    fill = openmc.HexLattice()
                    fill.universes = openmc_rings
                    #fill.num_rings = rings[1]
                    #fill.num_axial = dim[0]
                    # Get the pitch.
                    # Since we assume equal X and Y pitch, and because the 1st 
                    # and 2nd surfaces must be parallel, we just need the 
                    # distance for the first plane.
                    #lat_surf = next(iter(cell.region.get_surfaces().items()))[1]
                    #fill.pitch = [abs(next(iter(cell.region.get_surfaces().items()))[1].d)]
                    lat_surfs = list(cell.region.get_surfaces().items())
                    #print(lat_surfs)
                    fill.pitch = [plane_distance(lat_surfs[0][1], lat_surfs[1][1])]
                    fill.orientation = 'x'

                

                # Store universe ID of cells containing a lattice.
                # Used later to condense cells/universes.
                lat_universes[int(cell.universe.name)] = int(cell.name)
                # Used later for defining the pitch and translations
                lat_dims[int(cell.universe.name)] = dim

            # Fill cell.
            openmc_cells[int(c)].fill = fill
            # Apply cell transformation to filling universe.
            if transform is not None and isinstance(fill, openmc.Material) is False:
                #print(fill, openmc_cells[int(c)], tr[0])
                #openmc_cells[int(c)] = openmc_cells[int(c)].translation(tr[0])
                #
                #print(fill, openmc_cells[int(c)], tr[0])
                if tr[1] is not None:
                    #openmc_cells[int(c)] = openmc_cells[int(c)].rotation(tr[1])
                    openmc_cells[int(c)].rotation = tr[1]
                openmc_cells[int(c)].translation = tr[0]
            openmc_universes[int(k)].add_cell(openmc_cells[int(c)])
    print('Universe and Cell Translation Complete')
    
    '''
    Assign lattice parameters.
    Remove redundant universes.
    Lattice corrections.
    '''
    print('Constructing Lattices...')
    q = 0
    for k in lat_universes:
        # ID of a cell containing a lattice.
        cell_id = lat_universes[k]
        # Get the lattice object.
        lat_fill = openmc_cells[cell_id].fill
        # Lattice dimensions
        dims = lat_dims[k]
        # Go through cells and change the lattice universe fill to 
        # lattice object.
        for j in openmc_cells:
            if openmc_cells[j].fill == openmc_universes[k]:
                if isinstance(lat_fill, openmc.RectLattice):
                    #TODO: What if the boundary is not a rectangle?
                    # Use the region filled by the lattice to find the lower 
                    # left corner of the lattice.
                    # Assuming the cell is rectangular (6 planes)
                    xlim = []
                    ylim = []
                    zlim = []
                    surfs = openmc_cells[j].region.get_surfaces()
                    for s in surfs:
                        if isinstance(surfs[s], openmc.XPlane):
                            xlim.append(surfs[s].x0)
                        elif isinstance(surfs[s], openmc.YPlane):
                            ylim.append(surfs[s].y0)
                        elif isinstance(surfs[s], openmc.ZPlane):
                            zlim.append(surfs[s].z0)
                        elif isinstance(surfs[s], openmc.Plane):
                            #TODO: Consider off axis planes
                            if surfs[s].a == 1 and surfs[s].b == 0 and surfs[s].c == 0:
                                xlim.append(surfs[s].d)
                            elif surfs[s].a == 0 and surfs[s].b == 1 and surfs[s].c == 0:
                                ylim.append(surfs[s].d)
                            elif surfs[s].a == 0 and surfs[s].b == 0 and surfs[s].c == 1:
                                zlim.append(surfs[s].d)
                            else:
                                print("Lattice bounding box off-axis")
                        else:
                            print("LATTICE ERROR!")
                    lat_fill.lower_left = [min(xlim), min(ylim), min(zlim)]

                    # Calculate the pitch from the lattice dimensions and container cell limits.
                    # Note that the lattice dims are in z,y,x order.
                    pitch = []
                    pitch.append((max(xlim)-min(xlim)) / dims[2])
                    pitch.append((max(ylim)-min(ylim)) / dims[1])
                    pitch.append((max(zlim)-min(zlim)) / dims[0])
                    lat_fill.pitch = pitch

                    # Find transformation to center the lattice element at 0,0,0
                    dispX = 0 - (max(xlim) - (0.5*dims[2]*pitch[0]))
                    dispY = 0 - (max(ylim) - (0.5*dims[1]*pitch[1]))
                    dispZ = 0 - (max(zlim) - (0.5*dims[0]*pitch[2]))
                    # Currently assume no rotation.
                    lat_disp.append([dispX, dispY, dispZ])
                    
                    # Fill OpenMC cell with lattice.
                    #openmc_cells[j].fill = lat_fill
                #TODO: HEX Lattice!
                elif isinstance(lat_fill, openmc.HexLattice):
                    """Need to get:
                    2. outside universe - use universe from corner of MCNP definition
                    3. center of lattice - get center of region on MCNP lat cell
                    """
                    # Time for some assumptions...
                    # We assume the lattice boundary is pretty regular meaning that
                    # it is probably just defined by planes or a cylinder/quadric.
                    # We also assume the Z direction to be axial. 
                    # This should work as long as some sets of planes are axis aligned.
                    surfs = openmc_cells[j].region.get_surfaces()
                    x, y, z = 0, 0, 0
                    xlim = []
                    ylim = []
                    zlim = []
                    center = []
                    for s in surfs:
                        print(s)
                        print(surfs[s].bounding_box('-'))
                        print(surfs[s].bounding_box('+'))
                        if isinstance(surfs[s], openmc.XPlane):
                            xlim.append(surfs[s].x0)
                        elif isinstance(surfs[s], openmc.YPlane):
                            ylim.append(surfs[s].y0)
                        elif isinstance(surfs[s], openmc.ZPlane):
                            zlim.append(surfs[s].z0)
                        elif isinstance(surfs[s], openmc.Plane):
                            #TODO: Consider off axis planes
                            if surfs[s].a == 1 and surfs[s].b == 0 and surfs[s].c == 0:
                                xlim.append(surfs[s].d)
                            elif surfs[s].a == 0 and surfs[s].b == 1 and surfs[s].c == 0:
                                ylim.append(surfs[s].d)
                            elif surfs[s].a == 0 and surfs[s].b == 0 and surfs[s].c == 1:
                                zlim.append(surfs[s].d)
                            else:
                                print("Lattice bounding box off-axis")
                        elif isinstance(surfs[s], openmc.Quadric):
                            x = surfs[s].g * -0.5
                            y = surfs[s].h * -0.5
                            z = surfs[s].j * -0.5
                    #print(xlim, ylim, zlim)
                    if len(xlim) > 0:
                        center.append(min(xlim) + ((max(xlim)-min(xlim)) / 2))
                    else:
                        center.append(x)
                    if len(ylim) > 0:
                        center.append(min(ylim) + ((max(ylim)-min(ylim)) / 2))
                    else:
                        center.append(y)
                    if len(zlim) > 0:
                        center.append(min(zlim) + ((max(zlim)-min(zlim)) / 2))
                    else:
                        center.append(z)
                    #print(x,y,z)
                    #print(center)
                    
                    lat_fill.center = center
                    lat_disp.append([0-center[0], 0-center[1], 0-center[2]])
                    lat_fill.pitch.append((max(zlim)-min(zlim) / dims[0]))

                    print('HEX LATTICE!')

                # Fill OpenMC cell with lattice.
                openmc_cells[j].fill = lat_fill

        openmc_cells.pop(cell_id)
        openmc_universes.pop(k)

        '''
        Applies correction transformations to lattice elements.
        This repositions the lattice elements to be centered at 0,0,0.
        It is applied to each lattice seperately. This procedure assumes that
        all lattice elements are defined using the same center point as the lattice itself. 
        '''
        u_list = lat_u[q]
        #print(u_list)
        for r in range(len(u_list)):
            cells = u_list[r].cells
            for c in cells:
                #print(cells[c], lat_disp[q])
                cells[c].region = cells[c].region.translate(lat_disp[q])
                if isinstance(cells[c].fill, openmc.Material) is False:
                    cells[c] = cells[c].translation(lat_disp[q])
        q = q + 1
            
    # The root universe should always have ID 0. 
    # Universe 0 is the default universe in MCNP.
    geom = openmc.Geometry(openmc_universes[0])
    print('Cleaning Up OpenMC Surfaces...')
    geom.remove_redundant_surfaces()
    print('Done!')
    return(geom, mats)

def translate(mcnp_file):
    deck = mp.Deck().read(filename=mcnp_file, renumber=True)
    print('Decomposing Geometry...')
    decompose(deck)
    print('Cleaning Up MCNP Surface Cards...')
    deck.remove_redundant_surfaces()
    deck.remove_unused_surfaces()
    print('Translating MCNP => OpenMC\n')

    # Tuple with geometry and materials.
    model = mcnp_to_openmc(deck)
    model[1].export_to_xml(mcnp_file.replace('.mcnp', '.materials.xml')) # materials
    model[0].export_to_xml(mcnp_file.replace('.mcnp', '.geometry.xml')) # geometry